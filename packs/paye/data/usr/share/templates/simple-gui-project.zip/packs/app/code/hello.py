from libabr import System, Control, Files, Colors, Script, App, Res
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import uic

control = Control()
files = Files()
colors = Colors()
app = App()
res = Res()


class MainApp(QWidget):
    def __init__(self, ports):
        super(MainApp, self).__init__()

        self.Backend = ports[0]
        self.Env = ports[1]
        self.Widget = ports[2]
        self.AppName = ports[3]
        self.External = ports[4]

        self.Widget.Resize(self, 500, 300)
        self.Widget.SetWindowTitle("Hello World!")
        self.Widget.SetWindowIcon(QIcon(res.get(res.etc(self.AppName,'logo'))))
